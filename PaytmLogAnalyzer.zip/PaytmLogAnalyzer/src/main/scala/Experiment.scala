import org.apache.spark.sql.{SparkSession, functions}
import org.apache.spark._
import org.apache.spark.rdd.RDD
import org.apache.spark.graphx._
import java.sql.Timestamp
import java.text.SimpleDateFormat
import scala.io.Source
import scala.util.hashing.MurmurHash3

// case class for Forming the dataframe of the given dataset
case class ELBLog (  timestamp : String,  elb  : String , clientip : String, client_port :  Int  ,  backendip : String , backend_port : Int , request_processing_time : Double , backend_processing_time : Double, response_processing_time : Double , elb_status_code : String , backend_status_code : String , received_bytes : BigInt , sent_bytes : BigInt , request_verb : String , url  : String, protocol : String , user_agent : String , ssl_cipher : String , ssl_protocol : String)

object LogAnalyzer {

// Split the fields according to the regex expression
  def splitfields(line: String): ELBLog = {
    val pattern = "(\\S+) (\\S+) (\\S+):(\\d+) (\\S*) (\\S+) (\\S+) (\\S+) (\\S+) (\\S+) (\\S+) (\\S+) \"(\\S+) (\\S+) (.+)\" \"(.*)\" (\\S+) (\\S+)".r
    (line: @unchecked)
    match {
      case pattern(timestamp, elb, clientip, client_port, backendip, request_processing_time, backend_processing_time, response_processing_time, elb_status_code, backend_status_code, received_bytes, sent_bytes, request_verb, url, protocol, user_agent, ssl_cipher, ssl_protocol) => ELBLog(timestamp, elb, clientip, client_port.toInt, if (backendip == "-") "-" else backendip.split(":")(0), if (backendip == "-") 0 else backendip.split(":")(1).toInt, request_processing_time.toDouble, backend_processing_time.toDouble, response_processing_time.toDouble, elb_status_code, backend_status_code, BigInt(received_bytes), BigInt(sent_bytes), request_verb, url, protocol, user_agent, ssl_cipher, ssl_protocol)
    }
  }

  def main(args: Array[String]): Unit = {

    if (args.length < 2) {
      println("Session Time in mins and File Path to be given as parameters")
      sys.exit(0)
    }
    val Sessiontime : Int= args(0).toInt *60
    val FilePath : String = args(1)
      val conf = new SparkConf()
      .set("spark.sql.inMemoryColumnarStorage.compressed", "true")
      .set("spark.shuffle.compress", "true")
      .set("spark.dynamicAllocation.maxExecutors", "20")
      .set("spark.rdd.compress", "true")
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    import spark.implicits._
    val RawRDD = spark.sparkContext.textFile(FilePath)
    val ELBboundRDD = RawRDD.map(x => splitfields(x))
    val DFforManipulation = ELBboundRDD.toDF()
    DFforManipulation.withColumn("timestamp_timedt", $"timestamp".cast("timestamp")).createOrReplaceTempView("ELBLogs")
    spark.sql("select * , row_number () over ( order by 1 ) as rownum  from elblogs ").persist().createOrReplaceTempView("elblogs")

    /* We need to sessionize the ELBLogs based on Clientip and the timestamp of the request made by client .
    if difference of the timestamp of last request made by the client and the current timestamp is greater than 9000 seconds then the current request is
    considered to be a new session . This logic can be achieved through Recursive CTE in normal SQL but since Spark SQL does
    not support it I have used GraphX and Pregal API
    */
    // Getting all vertices of the graph . Rownum will be the unique identifier which will be used as VertexID after Long co0nversion
    val VerticesDF = spark.sql(" select rownum, timestamp_timedt  ,1 as NewLevel , 0 as OldLevel from ELBLogs  ")

    // Getting the Edge Attributes for association
    val EdgeDF = spark.sql("select currentrownumber,previousrownumber from(\n select   rownum as currentrownumber  , Lag (rownum,1  ) over ( partition by clientip order by timestamp_timedt  )  as PreviousRownumber , Lag (timestamp_timedt,1  ) over ( partition by clientip order by timestamp_timedt  )  as PreviousTimeStamp\n from ELBLogs    \n ) where PreviousTimeStamp is not null")

    var vertices: RDD[(VertexId, (Int, Timestamp ,Int, Int))] =
      VerticesDF.rdd.map(x => (MurmurHash3.stringHash(x.get(0).toString).toLong,( x.get(0).toString.toInt, java.sql.Timestamp.valueOf(x.get(1).toString) ,x.get(2).toString.toInt, x.get(3).toString.toInt )))
    vertices= vertices.repartition(6)

    var edgerdd = EdgeDF.rdd.map(x => (x.get(1), x.get(0))).map(x => Edge[String](MurmurHash3.stringHash(x._1.toString).toLong, MurmurHash3.stringHash(x._2.toString).toLong, "TD"))
    edgerdd= edgerdd.repartition(6)
    val graph = Graph(vertices, edgerdd).persist()
    val initialmsg = ( 0 ,Timestamp.valueOf("1980-01-01 00:00:00.000000") , 1,0)

    // Msgsetter function for comparing the current value with the incoming message and making a decision as to whether we need to
    // increase the Level or not
    def msgsetter(vertexId: VertexId, value: (  Int , Timestamp, Int, Int), message: ( Int, Timestamp, Int,Int)): (  Int , Timestamp, Int, Int) =
    {

      if ( message != initialmsg && ((value._2.getTime - message._2.getTime) / 1000 >= Sessiontime )  ) {
        ( value._1, value._2,  message._3+1, value._3)
      }
      else if (message._3 > value._3){
        ( value._1, value._2, value._3+1, value._3)
      }

      else {
        (  value._1 , value._2, value._3, value._4)
      }
    }


    // sendMsg sends a empty message if there is no change between the current value and received message. If there is a change
    // then the Destination Vertices are notified for the change so that they can make the changes.
    def sendMsg(triplet: EdgeTriplet[(  Int, Timestamp, Int, Int), String]): Iterator[(VertexId, ( Int, Timestamp, Int, Int))] = {
      val sourceVertex = triplet.srcAttr
      if (sourceVertex._3 == sourceVertex._4) {
        Iterator.empty
      }
      else {
        Iterator((triplet.dstId, (sourceVertex._1, sourceVertex._2, sourceVertex._3, sourceVertex._4)))
      }
    }

    // mergeMsg is not useful because of one - one mapping between vertices .
    def mergeMsg(message1: ( Int,Timestamp, Int ,Int), message2: ( Int, Timestamp, Int ,Int)): ( Int, Timestamp, Int,Int) = message1

    val finalgraph= graph.pregel(initialmsg,
      Int.MaxValue,
      EdgeDirection.Out)(
      msgsetter,
      sendMsg,
      mergeMsg).persist()

    graph.unpersist()
    // persisting the graph for further calculation and converting it to Dataframe for final calcuations
    finalgraph.mapVertices ( (id, x) => (x._1,x._2,x._3,x._4) ).vertices.map( x => (x._2._1,x._2._2,x._2._3,x._2._4)).toDF("rownum","timestamp_timedt","CurrentLevel","PreviousLevel").createOrReplaceTempView("ELBLogsWithLevel")

    //Average Session Time ( question 2)
    spark.sql (" select avg( sessiontime) from ( select clientip, unix_timestamp(max(EWL.timestamp_timedt)) - unix_timestamp(min(EWL.timestamp_timedt)) as sessiontime,currentLevel from elblogs EL inner join elblogsWithLevel  EWL on EL.rownum = EWL.rownum GROUP BY clientip, currentLevel) a ").show

    // count of distinct URL's per session ( question 3)
    spark.sql (" select clientip,URLCount from ( select clientip, count (distinct URL) as URLCount,currentLevel from elblogs EL inner join elblogsWithLevel  EWL on EL.rownum = EWL.rownum GROUP BY clientip, currentLevel) a ").show

    // Question 4 Topmost 5 IPs with longest session times
    spark.sql("select clientip,max(sessiontime) sessiontime  from ( select clientip, unix_timestamp(max(EWL.timestamp_timedt)) - unix_timestamp(min(EWL.timestamp_timedt)) as sessiontime,currentLevel from elblogs EL inner join elblogsWithLevel  EWL on EL.rownum = EWL.rownum GROUP BY clientip, currentLevel) a  group by clientip order by sessiontime desc limit 5").show

    finalgraph.unpersist()
    spark.stop()
  }



}
